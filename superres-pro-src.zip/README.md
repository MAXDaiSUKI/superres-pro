# 超境画质 PRO · SuperRes PRO

> 让任意游戏在 nubia / 红魔设备上出现系统原生的「超境画质」面板（超分 + 插帧 + 最高档位）。
> A KernelSU WebUI module that unlocks the stock **Super Resolution / Frame Interpolation** panel for any game on ZTE/nubia ROMs.

[![License: CC0-1.0](https://img.shields.io/badge/License-CC0%201.0-lightgrey.svg)](LICENSE)
![Platform](https://img.shields.io/badge/Platform-Android%2014%2B-green)
![Root](https://img.shields.io/badge/Root-KernelSU-blue)

---

## 这是什么

部分 nubia / 红魔（RedMagic）ROM 里带有一个由厂商 **GPP** 组件（`/system/bin/gppservice`）提供的「超境画质」能力：

- **超分（upscale）**：1.5× / 2× 神经网络放大
- **插帧（interp / FRC）**：把 60fps 的游戏补到 120 / 144Hz

但它**只对内置白名单里的游戏生效**，名单写死在只读分区 `/system/etc/gpp_app_list`。

本模块做的事情：

1. 用 **bind mount** 把「你勾选的名单」覆盖到 `/system/etc/gpp_app_list`，**不改 /system 分区**，卸载即还原；
2. 打开 **全局支持**（`vendor.gpp.allgame.enable=1`）后，Cube 对**任意游戏**都返回非 0 的 cap，游戏内就会出现原生「超境画质」面板；
3. 档位交给游戏内面板自己选，系统会把它写进 `game_gfrc_mode` —— 模块默认**不抢**这个值。

一句话：**勾上游戏 → 进游戏 → 打开悬浮面板的「超境画质」→ 自己选档位。**

---

## 三层机制

| 层 | 位置 | 作用 |
|---|---|---|
| ① 设备能力 | `ro.vendor.feature.zte_feature_gfrc=true` | ROM 级开关，改不了 |
| ② 游戏名单 | `/system/etc/gpp_app_list`（`包名,超分档,插帧`） | 决定「这个游戏能不能用」 |
| ③ 逐游戏档位 | `Settings.Global game_gfrc_mode`（`包名+超分,插帧,gfrc`） | 记录具体档位 |

模块在 ② 上做扩展，在 ③ 上默认只读不写（「面板优先」模式）。

---

## 功能

- 📋 **WebUI 名单管理**：搜索 / 勾选 / 下拉选档，不用敲命令
- 🎮 **全局支持**：一条开关让系统原本不支持的游戏也出现面板
- 🎚 **档位选择**：超分关 / 中（1.5×）/ 高（2×），插帧开 / 关
- ♻️ **面板优先**（默认）：改完存档，档位完全交给游戏内面板
- ✍️ **强制写入**（可选）：模块每 15 秒把档位写回 `game_gfrc_mode`，用于面板里没有的档位
- 📦 **零原生代码**：纯 shell + HTML，无 .so，无架构依赖
- 🧹 **可逆**：只读分区不动，卸载脚本自动 umount + 还原

---

## 兼容性

- **已验证**：nubia NX741J（Z80 Ultra）/ NebulaAIOS 2.0 / Android 16
- **前提**：设备必须真的具备该能力 —— 检查 `getprop ro.vendor.feature.zte_feature_gfrc` 为 `true`，且存在 `/system/bin/gppservice`
- **Root**：需要 KernelSU（或带 WebUI 的 KSU 分支，如 SukiSU / KernelSU Next）
- 红魔 9/10 系、部分 nubia Z 系理论上同理，欢迎反馈机型

---

## 安装

1. 下载 Release 里的 `gpp_extend_vX.Y.zip`
2. KernelSU 管理器 → **模块** → **从本地安装**
3. 安装完成后**重启一次**
4. 回到模块列表，点模块卡片上的 **「打开」**，进入 WebUI

> 不想重启也行：首次进 WebUI 点一次「保存并应用」，bind mount 立即生效；模块的 overlay 只在开机时挂载，作用是「重启后保持」。

---

## 使用

WebUI 顶部状态行：

| 显示 | 含义 |
|---|---|
| `服务 运行中 (pid)` | gppservice 在跑 |
| `注入 已生效` | `/system/etc/gpp_app_list` 已被模块覆盖 |
| `基础 N` | 原厂名单条目数（通常 240） |
| `已选 N` | 你勾选的数量 |
| `插帧 工作中/未激活` | `vendor.gpp.gfrc.interp.rate` 是否为 1 |

操作三步：**勾游戏 → 选档位 → 保存并应用**。

完整说明见 [docs/USAGE-zh.md](docs/USAGE-zh.md)。

---

## 参数速查

| 超分档 | 面板显示 | 实际行为 |
|---|---|---|
| `0` | 原始 | 不超分，只走插帧 |
| `1` | 高 | 1.5× 超分（`LowerPower_1p5x_LumaNet` 族） |
| `2` | 超高 | 2× 超分（`AIS_2x_AA_plus_StrongerTextureV4` 族） |

物理限制：

- 超分要求游戏**原始渲染分辨率 < 1080×2400**，否则不放大、只保留插帧
- 输出硬上限 **1728×3840**
- 游戏本身跑满屏幕原生分辨率（例如 1216×2688）时，超分看不到效果是正常的 —— 把游戏内画质调低反而更容易触发

---

## 验证

```sh
# 名单里是否有这个游戏
cat /system/etc/gpp_app_list | grep com.tencent.tmgp.sgame

# 是否建立了 GPP 会话
logcat -s GPP-Service | grep -E "createSession|Get layer name"

# 插帧是否在跑
getprop vendor.gpp.gfrc.interp.rate     # 1 = 在跑
getprop vendor.gpp.frc.enable           # 0x22 = 插帧通道已开

# 档位是否下发
logcat -s Cube_GfrcModeCtrl | grep -E "GfrcModeSettings|Enanble"
```

---

## 构建

```sh
python3 build_zip.py      # 产出 gpp_extend_v<版本>.zip
```

无第三方依赖，只用标准库（`zipfile`）。脚本会把 `docs/USAGE-zh.md` 以 `使用说明.md` 的名字打进包里，并给 `*.sh` 设置 `0755` 权限。

---

## 目录结构

```
├── module.prop                 # 模块信息（id/name/version/description）
├── apply.sh                    # 合并名单 + bind mount + 重启 gppservice + 同步 allgame
├── mode.sh                     # 合并写 game_gfrc_mode（仅强制写入模式）
├── service.sh                  # 常驻守护：单实例锁 + allgame 维持 + 可选 mode.sh
├── ctl.sh                      # 命令行：list / put / reset / status
├── uninstall.sh                # 卸载时 umount 并清理
├── system/etc/gpp_app_list     # 原厂名单副本（模块 overlay 用）
├── webroot/index.html          # WebUI
├── docs/
│   ├── USAGE-zh.md             # 使用说明（会打进 zip）
│   └── HOW-IT-WORKS-zh.md      # 原理与逆向笔记
└── .github/workflows/build.yml # CI：打 zip 并上传 artifact
```

运行时状态都在 `/data/adb/gpp_extend/`：`base_list`（原厂快照）、`state.txt`（你的勾选）、`allgame`、`force`。

---

## 常见问题

见 [docs/USAGE-zh.md 第 6 节](docs/USAGE-zh.md)。高频的几条：

- **勾了但游戏里没有面板** → 打开「全局支持」再保存，杀掉游戏重进
- **面板出现但档位是灰的** → 游戏渲染分辨率过高，或该档位底层不支持；可试「强制写入」
- **插帧看不出变化** → 确认 `interp.rate=1`，且游戏本身帧率低于屏幕刷新率
- **变卡/发热** → 超分和插帧是显示级管线，所有窗口都吃开销；不用时把「全局支持」关掉

---

## 原理与逆向笔记

机制怎么挖出来的（`gppservice` 的字符串、`game_gfrc_mode` 的位含义、超分模型族与尺寸限制、`allgame` 属性）：见 [docs/HOW-IT-WORKS-zh.md](docs/HOW-IT-WORKS-zh.md)。

---

## 免责声明

- 本项目是**社区逆向**产物，与中兴 / 努比亚 / 红魔官方**无关**，未获其授权或背书。
- 修改系统行为存在风险：可能导致耗电增加、发热、显示异常；OTA 后可能需要重新同步。
- 使用本模块造成的任何后果由使用者自行承担。

---

## License

本项目全部内容（脚本、WebUI、文档）以 **CC0 1.0 Universal** 释出，即**放弃著作权、进入公有领域**，可任意使用、修改、商用，无需署名。

详见 [LICENSE](LICENSE)。
